import argparse
import errno
import main
import os

if __name__ == '__main__':
    # Training settings
    parser = argparse.ArgumentParser(description='PyTorch MNIST Example')
    parser.add_argument('--batch-size', type=int, default=64, metavar='N',
                        help='input batch size for training (default: 64)')
    parser.add_argument('--test-batch-size', type=int, default=1000, metavar='N',
                        help='input batch size for testing (default: 1000)')
    parser.add_argument('--epochs', type=int, default=10, metavar='N',
                        help='number of epochs to train (default: 10)')
    parser.add_argument('--lr', type=float, default=0.01, metavar='LR',
                        help='learning rate (default: 0.01)')
    parser.add_argument('--momentum', type=float, default=0.5, metavar='M',
                        help='SGD momentum (default: 0.5)')
    parser.add_argument('--no-cuda', action='store_true', default=False,
                        help='disables CUDA training')
    parser.add_argument('--seed', type=int, default=1, metavar='S',
                        help='random seed (default: 1)')
    parser.add_argument('--log-interval', type=int, default=10, metavar='N',
                        help='how many batches to wait before logging training status')
    parser.add_argument('--data-dir', type=str, default='$DATA_DIR', metavar='N',
                        help='directory location to store the training and test data.')
    parser.add_argument('--result-dir', type=str, default='$RESULT_DIR', metavar='N',
                        help='directory location to store the training result.')
    args= parser.parse_args()

    print("Start Watson ML training run ....")

    if (args.result_dir[0] == '$'):
        args.result_dir = os.environ[args.result_dir[1:]]
    if (args.data_dir[0] == '$'):
        args.data_dir = os.environ[args.data_dir[1:]]
    
    main.main(args)


